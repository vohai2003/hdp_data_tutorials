#!/bin/bash
sudo groupadd audit
sudo groupadd hr

sudo useradd -G hadoop admin
sudo usermod -a -G users admin
sudo -H -u hdfs bash -c 'hdfs dfs -mkdir /user/admin'
sudo -H -u hdfs bash -c 'hdfs dfs -chown admin:hadoop /user/admin'
sudo -H -u hdfs bash -c 'hdfs dfs -chmod 755 /user/admin'

sudo useradd -G hadoop hr_admin
sudo usermod -a -G hadoop hr_admin
sudo -H -u hdfs bash -c 'hdfs dfs -mkdir /user/hr_admin'
sudo -H -u hdfs bash -c 'hdfs dfs -chown hr_admin:hadoop /user/hr_admin'
sudo -H -u hdfs bash -c 'hdfs dfs -chmod 755 /user/hr_admin'

sudo useradd -G hadoop hr_user
sudo usermod -a -G hadoop hr_user
sudo -H -u hdfs bash -c 'hdfs dfs -mkdir /user/hr_user'
sudo -H -u hdfs bash -c 'hdfs dfs -chown hr_user:hadoop /user/hr_user'
sudo -H -u hdfs bash -c 'hdfs dfs -chmod 755 /user/hr_user'


sudo useradd -G hadoop fin_admin
sudo usermod -a -G hadoop fin_admin
sudo -H -u hdfs bash -c 'hdfs dfs -mkdir /user/fin_admin'
sudo -H -u hdfs bash -c 'hdfs dfs -chown fin_admin:hadoop /user/fin_admin'
sudo -H -u hdfs bash -c 'hdfs dfs -chmod 755 /user/fin_admin'

sudo useradd -G hadoop fin_user
sudo usermod -a -G hadoop fin_user
sudo usermod -a -G audit fin_user
sudo -H -u hdfs bash -c 'hdfs dfs -mkdir /user/fin_user'
sudo -H -u hdfs bash -c 'hdfs dfs -chown fin_user:hadoop /user/fin_user'
sudo -H -u hdfs bash -c 'hdfs dfs -chmod 755 /user/fin_user'
