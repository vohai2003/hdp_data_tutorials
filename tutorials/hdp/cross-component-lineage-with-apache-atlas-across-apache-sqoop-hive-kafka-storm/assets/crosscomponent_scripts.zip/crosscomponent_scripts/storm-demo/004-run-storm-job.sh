#!/bin/bash
storm jar /root/crosscomponent_demo/crosscomponent_scripts/storm-demo/lib/storm-samples-1.0-jar-with-dependencies.jar com.dsinpractice.storm.samples.WordCountTopology --cluster true --name storm-demo-topology-01 --path /user/storm/storm-hdfs-test-01 --topic my-topic-01
