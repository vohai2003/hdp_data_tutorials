create table cur_hive_table1 as select * from test_hive_table1 ;
